import os
import boto3
from nltk.sentiment import SentimentIntensityAnalyzer
import nltk
# Get the directory of the current Python script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct full path to 'nltk_data' folder inside the script directory
nltk_data_path = os.path.join(script_dir, 'nltk_data')

# Set nltk.data.path to a list with that path
nltk.data.path = [nltk_data_path]

print("NLTK data path set to:")
print(nltk.data.path)

sia = SentimentIntensityAnalyzer()

endpoint_url = None
if os.getenv("STAGE") == "local":
    endpoint_url = "http://localhost.localstack.cloud:4566"

s3 = boto3.client("s3", endpoint_url=endpoint_url)
ssm = boto3.client("ssm", endpoint_url=endpoint_url)
dynamodb = boto3.client("dynamodb",endpoint_url=endpoint_url)


def get_sentiment(text):
    scores = sia.polarity_scores(text)
    if scores['compound'] >= 0.1:
        return 'POSITIVE'
    elif scores['compound'] <= -0.1:
        return 'NEGATIVE'
    else:
        return 'NEUTRAL'

def handler(event, context):
    reviews_table = ssm.get_parameter(Name='/review-app/tables/reviews')['Parameter']['Value']
    
    for record in event['Records']:
        if record['eventName'] == 'INSERT':
            review_id = record['dynamodb']['Keys']['reviewId']['S']
            review = record['dynamodb']['NewImage']
            
            overall_sentiment = get_sentiment(review['processedreviewText']['S'] + " " + review['processedSummary']['S'])
            
            res = dynamodb.update_item(
                TableName=reviews_table,
                Key={'reviewId': {'S': review_id}},
                UpdateExpression='SET sentiment = :sent',
                ExpressionAttributeValues={':sent': {'S': overall_sentiment}}
            )
            print("Sentiment result", res)
    return {'statusCode': 200}